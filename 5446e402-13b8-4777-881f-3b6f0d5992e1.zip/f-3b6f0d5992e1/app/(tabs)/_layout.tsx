
import React from 'react';
import { Platform } from 'react-native';
import { NativeTabs, Icon, Label } from 'expo-router/unstable-native-tabs';
import { Stack } from 'expo-router';
import FloatingTabBar, { TabBarItem } from '@/components/FloatingTabBar';
import { colors } from '@/styles/commonStyles';

export default function TabLayout() {
  const tabs: TabBarItem[] = [
    {
      name: '(home)',
      route: '/(tabs)/(home)/',
      icon: 'house.fill',
      label: 'Dashboard',
    },
    {
      name: 'trainings',
      route: '/(tabs)/trainings',
      icon: 'figure.strengthtraining.traditional',
      label: 'Trainings',
    },
    {
      name: 'bodydata',
      route: '/(tabs)/bodydata',
      icon: 'chart.line.uptrend.xyaxis',
      label: 'Körperdaten',
    },
    {
      name: 'settings',
      route: '/(tabs)/settings',
      icon: 'gear',
      label: 'Einstellungen',
    },
  ];

  if (Platform.OS === 'ios') {
    return (
      <NativeTabs>
        <NativeTabs.Trigger name="(home)">
          <Icon sf="house.fill" drawable="ic_home" />
          <Label>Dashboard</Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="trainings">
          <Icon sf="figure.strengthtraining.traditional" drawable="ic_fitness" />
          <Label>Trainings</Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="bodydata">
          <Icon sf="chart.line.uptrend.xyaxis" drawable="ic_chart" />
          <Label>Körperdaten</Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="settings">
          <Icon sf="gear" drawable="ic_settings" />
          <Label>Einstellungen</Label>
        </NativeTabs.Trigger>
      </NativeTabs>
    );
  }

  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'none',
        }}
      >
        <Stack.Screen name="(home)" />
        <Stack.Screen name="trainings" />
        <Stack.Screen name="bodydata" />
        <Stack.Screen name="settings" />
      </Stack>
      <FloatingTabBar tabs={tabs} />
    </>
  );
}
