
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  RefreshControl,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { useAppTheme } from '@/contexts/ThemeContext';
import { getBodyMeasurements } from '@/utils/storage';
import { BodyMeasurement } from '@/types/workout';

export default function BodyDataScreen() {
  const { colors } = useAppTheme();
  const router = useRouter();
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadMeasurements();
  }, []);

  const loadMeasurements = async () => {
    const loadedMeasurements = await getBodyMeasurements();
    setMeasurements(loadedMeasurements.sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    ));
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadMeasurements();
    setRefreshing(false);
  };

  const getLatestMeasurement = () => {
    return measurements.length > 0 ? measurements[0] : null;
  };

  const latest = getLatestMeasurement();

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: 'Körperdaten',
            headerLargeTitle: true,
          }}
        />
      )}
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView
          contentContainerStyle={[
            styles.scrollContent,
            Platform.OS !== 'ios' && styles.scrollContentWithTabBar,
          ]}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          {Platform.OS !== 'ios' && (
            <Text style={[styles.header, { color: colors.text }]}>Körperdaten</Text>
          )}

          <TouchableOpacity
            style={[styles.addButton, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/add-measurement')}
          >
            <IconSymbol name="plus" size={24} color="#FFFFFF" />
            <Text style={styles.addButtonText}>Neue Messung hinzufügen</Text>
          </TouchableOpacity>

          {latest && (
            <View style={styles.section}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                Aktuelle Werte
              </Text>
              <View style={[styles.card, { backgroundColor: colors.card }]}>
                <Text style={[styles.cardDate, { color: colors.textSecondary }]}>
                  {new Date(latest.date).toLocaleDateString('de-DE')}
                </Text>
                <View style={styles.measurementGrid}>
                  {latest.weight && (
                    <View style={styles.measurementItem}>
                      <IconSymbol name="scalemass" size={24} color={colors.primary} />
                      <Text style={[styles.measurementLabel, { color: colors.textSecondary }]}>
                        Gewicht
                      </Text>
                      <Text style={[styles.measurementValue, { color: colors.text }]}>
                        {latest.weight} kg
                      </Text>
                    </View>
                  )}
                  {latest.chest && (
                    <View style={styles.measurementItem}>
                      <IconSymbol name="figure.arms.open" size={24} color={colors.primary} />
                      <Text style={[styles.measurementLabel, { color: colors.textSecondary }]}>
                        Brust
                      </Text>
                      <Text style={[styles.measurementValue, { color: colors.text }]}>
                        {latest.chest} cm
                      </Text>
                    </View>
                  )}
                  {latest.waist && (
                    <View style={styles.measurementItem}>
                      <IconSymbol name="figure.stand" size={24} color={colors.primary} />
                      <Text style={[styles.measurementLabel, { color: colors.textSecondary }]}>
                        Taille
                      </Text>
                      <Text style={[styles.measurementValue, { color: colors.text }]}>
                        {latest.waist} cm
                      </Text>
                    </View>
                  )}
                  {latest.upperArm && (
                    <View style={styles.measurementItem}>
                      <IconSymbol name="figure.strengthtraining.traditional" size={24} color={colors.primary} />
                      <Text style={[styles.measurementLabel, { color: colors.textSecondary }]}>
                        Oberarm
                      </Text>
                      <Text style={[styles.measurementValue, { color: colors.text }]}>
                        {latest.upperArm} cm
                      </Text>
                    </View>
                  )}
                  {latest.thigh && (
                    <View style={styles.measurementItem}>
                      <IconSymbol name="figure.walk" size={24} color={colors.primary} />
                      <Text style={[styles.measurementLabel, { color: colors.textSecondary }]}>
                        Oberschenkel
                      </Text>
                      <Text style={[styles.measurementValue, { color: colors.text }]}>
                        {latest.thigh} cm
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            </View>
          )}

          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              Verlauf
            </Text>
            {measurements.length === 0 ? (
              <View style={[styles.emptyCard, { backgroundColor: colors.card }]}>
                <IconSymbol
                  name="chart.line.uptrend.xyaxis"
                  size={64}
                  color={colors.textSecondary}
                />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  Noch keine Messungen vorhanden
                </Text>
                <Text style={[styles.emptySubtext, { color: colors.textSecondary }]}>
                  Füge deine erste Messung hinzu
                </Text>
              </View>
            ) : (
              measurements.map(measurement => (
                <View
                  key={measurement.id}
                  style={[styles.historyCard, { backgroundColor: colors.card }]}
                >
                  <Text style={[styles.historyDate, { color: colors.text }]}>
                    {new Date(measurement.date).toLocaleDateString('de-DE')}
                  </Text>
                  <View style={styles.historyValues}>
                    {measurement.weight && (
                      <Text style={[styles.historyValue, { color: colors.textSecondary }]}>
                        Gewicht: {measurement.weight} kg
                      </Text>
                    )}
                    {measurement.chest && (
                      <Text style={[styles.historyValue, { color: colors.textSecondary }]}>
                        Brust: {measurement.chest} cm
                      </Text>
                    )}
                    {measurement.waist && (
                      <Text style={[styles.historyValue, { color: colors.textSecondary }]}>
                        Taille: {measurement.waist} cm
                      </Text>
                    )}
                  </View>
                </View>
              ))
            )}
          </View>
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  scrollContentWithTabBar: {
    paddingBottom: 100,
  },
  header: {
    fontSize: 32,
    fontWeight: '700',
    marginBottom: 24,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 12,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  cardDate: {
    fontSize: 14,
    marginBottom: 16,
  },
  measurementGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  measurementItem: {
    width: '47%',
    alignItems: 'center',
    padding: 12,
  },
  measurementLabel: {
    fontSize: 12,
    marginTop: 8,
  },
  measurementValue: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 4,
  },
  emptyCard: {
    borderRadius: 12,
    padding: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  historyCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
    elevation: 1,
  },
  historyDate: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  historyValues: {
    gap: 4,
  },
  historyValue: {
    fontSize: 14,
  },
});
